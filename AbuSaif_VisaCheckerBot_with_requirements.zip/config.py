# config.py
TOKEN = 'ضع_توكن_البوت_هنا'
OWNER = 'ابو سيف'
