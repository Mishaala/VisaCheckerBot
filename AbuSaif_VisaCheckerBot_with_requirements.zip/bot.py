# bot.py
import random
import requests
from aiogram import Bot, Dispatcher, executor, types
import config
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
import asyncio
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware

bot = Bot(token=config.TOKEN)
dp = Dispatcher(bot)

user_checks = {}

class ThrottleMiddleware(BaseMiddleware):
    def __init__(self, rate_limit=5):
        self.rate_limit = rate_limit
        super(ThrottleMiddleware, self).__init__()

    async def on_process_message(self, message, data):
        dp = message.bot.dispatcher
        if hasattr(dp, 'throttle'):
            await dp.throttle('key', rate=self.rate_limit)
            raise CancelHandler()
        dp.throttle = lambda *args, **kwargs: asyncio.sleep(self.rate_limit)

def luhn(card_number):
    num = [int(x) for x in str(card_number)][::-1]
    checksum = 0
    for i, digit in enumerate(num):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    return checksum % 10 == 0

def get_bin_info(card_number):
    try:
        bin_number = str(card_number)[:8]
        response = requests.get(f"https://lookup.binlist.net/{bin_number}")
        if response.status_code == 200:
            return response.json()
        else:
            return None
    except:
        return None

def generate_balance():
    return random.randint(100, 5000)

def generate_keyboard():
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(text="🔁 تحقق مرة أخرى", callback_data="retry"),
        InlineKeyboardButton(text="🏠 رجوع للبداية", callback_data="start")
    )
    return keyboard

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    user_name = message.from_user.first_name
    text = (
        f"┏━━━━━━━━━━━━━━━━━━━━━┓\n"
        f"┃   مرحباً {user_name} في أقوى فاحص بطاقات   ┃\n"
        f"┃         بإدارة {config.OWNER}         ┃\n"
        f"┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"استخدم الأمر /check <رقم البطاقة>\n"
        f"➤ Example:\n"
        f"/check 4000056655665556\n\n"
        f"اكتب /stats لمشاهدة عدد البطاقات التي قمت بفحصها."
    )
    await message.answer(text)

@dp.message_handler(commands=['stats'])
async def stats(message: types.Message):
    user_id = message.from_user.id
    checks = user_checks.get(user_id, 0)
    await message.reply(f"📊 لقد قمت بفحص {checks} بطاقة حتى الآن!\n\nحقوق © {config.OWNER}")

@dp.message_handler(commands=['check'])
async def check_card(message: types.Message):
    try:
        card_number = message.get_args().strip()
        if not card_number.isdigit():
            await message.reply("❌ الرجاء إدخال رقم بطاقة صحيح.\n\nPlease send a valid card number.")
            return
        if not 12 <= len(card_number) <= 19:
            await message.reply("❌ رقم البطاقة يجب أن يكون بين 12 و19 رقمًا.\n\nCard number must be between 12 and 19 digits.")
            return

        valid = luhn(card_number)
        bin_info = get_bin_info(card_number)

        if not bin_info:
            await message.reply("❌ لم أتمكن من جلب معلومات البطاقة.\n\nFailed to fetch card information.")
            return

        country = bin_info.get('country', {}).get('name', 'غير معروف / Unknown')
        scheme = bin_info.get('scheme', 'غير معروف / Unknown')
        card_type = bin_info.get('type', 'غير معروف / Unknown')
        bank_name = bin_info.get('bank', {}).get('name', 'غير معروف / Unknown')
        balance = generate_balance()

        status = "✅ صالحة / Valid" if valid else "❌ غير صالحة / Invalid"

        reply_text = (
            f"┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            f"┃      فحص البطاقة       ┃\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"🔹 الحالة / Status: {status}\n"
            f"🔹 نوع البطاقة / Card Scheme: {scheme.capitalize()}\n"
            f"🔹 نوع الاستخدام / Card Type: {card_type.capitalize()}\n"
            f"🔹 البنك / Bank: {bank_name}\n"
            f"🔹 الدولة / Country: {country}\n"
            f"🔹 رصيد تقديري / Estimated Balance: ${balance}\n\n"
            f"حقوق © {config.OWNER}"
        )

        await message.reply(reply_text, reply_markup=generate_keyboard())

        user_id = message.from_user.id
        user_checks[user_id] = user_checks.get(user_id, 0) + 1

    except Exception as e:
        await message.reply(f"❌ حصل خطأ أثناء الفحص.\n\nError: {str(e)}")

@dp.message_handler(content_types=['text'])
async def bulk_check(message: types.Message):
    cards = message.text.strip().split('\n')
    if len(cards) > 1:
        results = []
        user_id = message.from_user.id
        for card in cards:
            card = card.strip()
            if card.isdigit() and 12 <= len(card) <= 19:
                valid = luhn(card)
                bin_info = get_bin_info(card)
                if bin_info:
                    country = bin_info.get('country', {}).get('name', 'Unknown')
                    scheme = bin_info.get('scheme', 'Unknown')
                    balance = generate_balance()
                    status = "✅ Valid" if valid else "❌ Invalid"
                    result = f"{card}: {status} - {scheme.upper()} - {country} - ${balance}"
                else:
                    result = f"{card}: ❌ Unknown"
                user_checks[user_id] = user_checks.get(user_id, 0) + 1
                results.append(result)
            else:
                results.append(f"{card}: ❌ Invalid Format")

        reply_text = "\n".join(results)
        if len(reply_text) > 4096:
            for x in range(0, len(reply_text), 4096):
                await message.reply(reply_text[x:x+4096])
        else:
            await message.reply(reply_text)

@dp.callback_query_handler(lambda c: c.data == 'retry')
async def retry_check(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(callback_query.from_user.id, "🔹 أرسل رقم البطاقة للتحقق مرة أخرى:")

@dp.callback_query_handler(lambda c: c.data == 'start')
async def return_home(callback_query: types.CallbackQuery):
    await bot.answer_callback_query(callback_query.id)
    await send_welcome(callback_query.message)

if __name__ == '__main__':
    print(f"بوت {config.OWNER} جاهز للعمل...")
    executor.start_polling(dp, skip_updates=True)
